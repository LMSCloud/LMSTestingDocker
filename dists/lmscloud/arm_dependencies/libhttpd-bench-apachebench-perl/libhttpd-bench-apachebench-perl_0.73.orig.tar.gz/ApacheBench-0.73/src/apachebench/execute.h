void initialize(struct global * registry);
static void test(struct global * registry);
