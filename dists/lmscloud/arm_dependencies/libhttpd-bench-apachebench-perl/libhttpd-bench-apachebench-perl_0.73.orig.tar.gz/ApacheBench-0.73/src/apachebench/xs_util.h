static SV * call_perl_function__one_arg(SV * function_name, SV * arg1);
