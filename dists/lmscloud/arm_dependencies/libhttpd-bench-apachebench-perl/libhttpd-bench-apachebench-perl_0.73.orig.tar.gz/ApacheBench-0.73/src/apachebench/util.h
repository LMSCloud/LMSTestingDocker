static void myerr(char *warn_and_error, char *s);
static int timedif(struct timeval a, struct timeval b);
static struct timeval double2timeval(double secs);
static double timeval2double(struct timeval a);

extern char * strnstr(const char *big, const char *little, size_t len);
