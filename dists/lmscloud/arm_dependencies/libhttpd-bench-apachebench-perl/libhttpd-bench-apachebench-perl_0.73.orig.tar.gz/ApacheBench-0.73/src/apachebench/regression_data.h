static void store_regression_data(struct global * registry, struct connection * c);
