$VAR1 = {
  'aaaa' => '1',
  'bbbb' => '2'
};
